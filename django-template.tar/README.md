# Template Django

This template of Django project is made thinking to work on Red Hat Openshift.
The production environment work with supervisor and gunicorn.


Change all mywebsite occurencies to name of project. 

Tip: Use the setup.sh to change occurencies, just change the value of _CHANGEHERE_.