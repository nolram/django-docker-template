# Template Django

Change all mywebsite occurencies to name of project. Tip: Use the setup.sh to change occurencies, just change the value of _CHANGEHERE_.